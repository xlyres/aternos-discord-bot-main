# aternos discord bot privacy policy
By using this discord bot you automatically agree to the following privacy terms:

Persistent data that we store to provide the service:
* Authentication credentials
* Discord guild/server ID
* Date created (i.e. when initially configured)
* Date modified (i.e. when last reconfigured)

Temporary data (logs) that we store to debug problems:
* Discord server ID
* Discord server name
* Minecraft server status
* Connection status

You can delete your personal data by removing the bot from your discord server.
Logs are not stored on disk and flushed periodically.

If you have any more questions about this privacy policy or the TOS, [open a discussion](https://github.com/sleeyax/aternos-discord-bot/discussions/categories/q-a) on this GitHub repository.
