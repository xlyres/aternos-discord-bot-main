# aternos discord bot TOS
By using this discord bot you automatically agree to the following terms of service:

1. This software breaks the [Aternos TOS](https://aternos.gmbh/en/aternos/terms). 
I do not take any responsibility if your account gets suspended, so use at your own risk!
2. The software and/or its source code might be taken down or stop working at any point in time without prior warning.
3. Your credentials (to log on to aternos.org) are processed and stored in order for the bot to support multiple discord servers. 
Since the source code of this bot is publicly available, anyone can host an instance. 
Therefore the security of your credentials may vary from instance to instance. 
If you want to be sure your credentials are safe, [host an instance yourself](./README.md#self-hosting).

If you have any more questions about this TOS or the privacy policy, [open a discussion](https://github.com/sleeyax/aternos-discord-bot/discussions/categories/q-a) on this GitHub repository.